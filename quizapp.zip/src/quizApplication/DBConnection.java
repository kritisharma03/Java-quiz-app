package quizApplication;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBConnection {
    static Connection connection =null;
    static String dbName ="ScoreDB";
    static String url = "jdbc:mysql://localhost:3306/"+dbName;
    static String username = "root";
    static String password = "aqswdefrg#";

public static Connection getConnection() {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver"); // Modern MySQL driver
        return DriverManager.getConnection(url,username,password);
    } catch (Exception e) {
//        e.printStackTrace();
        return null;
    }
}

// ✅ Method to Insert Quiz Scores into Database
public static void saveScore(String name, String rollno, int score, int totalQuestions) {
    String query = "INSERT INTO score (name, roll_no, score, total_ques) VALUES (?, ?, ?, ?)";

    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(query)) {
        stmt.setString(1, name);
        stmt.setInt(2, Integer.parseInt(rollno));
        stmt.setInt(3, score);
        stmt.setInt(4, totalQuestions);
        stmt.executeUpdate();
//        System.out.println("✅ Score saved successfully!");
    } catch (SQLException e) {
//        e.printStackTrace();  // ❌ If an error occurs, print it
    }
}

// ✅ Test the connection
public static void main(String[] args) {
    Connection conn = getConnection();
    if (conn != null) {
        System.out.println("✅ Database Connected Successfully!");
    } else {
        System.out.println("❌ Database Connection Failed!");
    }
}
}

