package quizApplication;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
// Question class to store questions and options
class Question {
    private String questionText;
    private List<String> options;
    private String correctAnswer;

    public Question(String questionText, List<String> options, String correctAnswer) {
        this.questionText = questionText;
        this.options = options;
        this.correctAnswer = correctAnswer;
    }

    public String getQuestionText() {
        return questionText;
    }

    public List<String> getOptions() {
        return options;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }
}
public class QuestionBank {
    public static List<Question> getQuestions() {
        List<Question> questions = new ArrayList<>();

        questions.add(new Question(" Who invented Java Programming?",
                Arrays.asList("James Gosling", "Dennis Ritchie", "Bjarne Stroustrup", "Guido van Rossum"), "James Gosling"));

        questions.add(new Question(" Which component is used to compile, debug and execute the java programs?",
                Arrays.asList("JRE","JIT", "JDK", "JVM"), "JDK"));

        questions.add(new Question("Which of these cannot be used for a variable name in Java?",
                Arrays.asList("identifier & keyword", "identifier", " keyword", " variable"), "keyword"));

        questions.add(new Question("Which of the following for loop declaration is not valid?",
                Arrays.asList("for ( int i = 99; i >= 0; i / 9 )", "for ( int i = 7; i <= 77; i += 7 )", "for ( int i = 20; i >= 2; - -i )",
                        "for ( int i = 2; i <= 20; i = 2* i )"), "for ( int i = 99; i >= 0; i / 9 )"));

        questions.add(new Question("Which environment variable is used to set the java path?",
                Arrays.asList(" MAVEN_Path", "JavaPATH", "JAVA", "JAVA_HOME"), "JAVA_HOME"));

        questions.add(new Question("Which of the following is not an OOPS concept in Java?",
                Arrays.asList("Polymorphism", "Inheritence", "Compilation", "Encapsulation"), "Compilation"));

        questions.add(new Question("What is not the use of “this” keyword in Java?",
                Arrays.asList(" Referring to the instance variable when a local variable has the same name", "Passing itself to the method of the same class",
                        "Passing itself to another method", "Calling another constructor in constructor chaining"),
                "Passing itself to the method of the same class"));

        questions.add(new Question(" Which of the following is a type of polymorphism in Java Programming?",
                Arrays.asList("Multiple polymorphism", "Compile time polymorphism", "Multilevel polymorphism", "Execution time polymorphism"),
                " Compile time polymorphism"));

        questions.add(new Question("Which exception is thrown when java is out of memory?",
                Arrays.asList("MemoryError","OutOfMemoryError", "MemoryOutOfBoundsException", "MemoryFullException")," OutOfMemoryError"));

        questions.add(new Question(" Which of the following is a superclass of every class in Java?",
                Arrays.asList("ArrayList", "Abstract class", "Object class", "String"), "Object class"));

        questions.add(new Question("Which of these statements is incorrect about Thread?",
                Arrays.asList(" start() method is used to begin execution of the thread",
                        "run() method is used to begin execution of a thread before start() method in special cases",
                        "A thread can be formed by implementing Runnable interface only",
                        "A thread can be formed by a class that extends Thread class"),
                "run() method is used to begin execution of a thread before start() method in special cases"));

        questions.add(new Question(" Which of these keywords are used for the block to be examined for exceptions?",
                Arrays.asList("check", "throw", "catch", "try"), "try"));

        questions.add(new Question("In Java, we can make a class abstract by-",
                Arrays.asList("Declaring it using the abstract keyword.", "Making at least one method final.", "Declaring all methods as static.",
                        "Declaring at least one method as abstract."), "Declaring it using the abstract keyword."));

        questions.add(new Question("Which of the following is true about an abstract class in Java?",
                Arrays.asList("It can be instantiated directly.", "It can contain both abstract and non-abstract methods.",
                        "All methods in an abstract class must be abstract.", "It cannot have a constructor."), "It can contain both abstract and non-abstract methods."));

        questions.add(new Question(" What is the use of final keyword in Java?",
                Arrays.asList("When a class is made final, a subclass of it can not be created.",
                        "When a method is final, it can not be overridden.",
                        "When a variable is final, it can be assigned value only once.",
                        "All of the above"), "All of the above"));

        questions.add(new Question(" Which of the following option leads to the portability and security of Java?",
                Arrays.asList("Bytecode is executed by JVM","The applet makes the Java code secure and portable",
                        "Use of exception handling", "Dynamic binding between objects"), "Bytecode is executed by JVM"));

        questions.add(new Question("What is used to find and fix bugs in the Java programs.?",
                Arrays.asList("JRE","JIT", "JDK", "JDB"), "JDB"));

        questions.add(new Question("Which of the following is a valid declaration of a char?",
                Arrays.asList("char ch = '\\utea';", "char ca = 'tea';", "char cr = \\u0223;", "char cc = '\\itea';"), "char ch = '\\utea';"));

        questions.add(new Question("What does the expression float a = 35 / 0 return?",
                Arrays.asList("0","Not a Number", "Infinity", "Run time exception"), "Infinity"));

        questions.add(new Question("Evaluate the following Java expression, ++z + y - y + z + x++:  if x=3, y=5, and z=10:",
                Arrays.asList("24", "23", "20", "25"), "25"));
        Collections.shuffle(questions); // Shuffle questions for randomness
        return questions;
    }
}
